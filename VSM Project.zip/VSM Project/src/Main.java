import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException {
        MarketReader mkt = new MarketReader();
        double totalRatingDiff = 0;
        // Part I: User Interaction with Web Scraper

        HashMap<String, HashMap<String, HashMap<ArrayList<String>, Float>>> data = new HashMap<>();



        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));


        System.out.println("What is the first industry you want?");
        System.out.println("");
        // Reading data using readLine
        String firstIndustry = reader.readLine();
        // Printing the read line
        System.out.println("What is the second industry you want?");
        System.out.println("");
        String secondIndustry = reader.readLine();
        System.out.println("Sample Size?");
        String sampleSize = reader.readLine();
        data = mkt.runExperiment(firstIndustry,secondIndustry, sampleSize);

        for (String key : data.keySet()){
            System.out.println(key);
            for (String key2 : data.get(key).keySet()){
                System.out.println(key2);
                for (ArrayList<String> key3 : data.get(key).get(key2).keySet()){
                    System.out.println(key3);
                    System.out.println(data.get(key).get(key2).get(key3));
                }
            }
        }

        HashMap<String, HashMap<ArrayList<String>, Float>> industryOneCompanies = data.get(firstIndustry);
        HashMap<String, HashMap<ArrayList<String>, Float>> industryTwoCompanies = data.get(secondIndustry);

        ArrayList<Document> documents = new ArrayList<Document>();

        // populate documents with industryOne companies
        for (String company : industryOneCompanies.keySet()) {
            Document d = new Document(company, industryOneCompanies.get(company).keySet().iterator().next());
            documents.add(d);
        }

        double similarity = 0;
        int comparisons = 0;

        // aggregate average cosine similarity data for 2 industries using industryOne as foundational Corpus
        for (String company : industryTwoCompanies.keySet()) {
            // add industryTwo company to corpus for comparisons
            Document query = new Document(company, industryTwoCompanies.get(company).keySet().iterator().next());
            documents.add(query);

            Corpus testingCorpus = new Corpus(documents);
            VectorSpaceModel testingVectorSpace = new VectorSpaceModel(testingCorpus);

            // compare industryTwo company to all industryOne companies
            for (Document doc : documents) {
                if (!doc.equals(query)) {
                    ArrayList<String> key1 = industryTwoCompanies.get(query.getDocName()).keySet().iterator().next();
                    ArrayList<String> key2 = industryOneCompanies.get(doc.getDocName()).keySet().iterator().next();

                    double ratingDiff = Math.abs(industryTwoCompanies.get(query.getDocName()).get(key1) -
                            industryOneCompanies.get(doc.getDocName()).get(key2));
                    totalRatingDiff += ratingDiff;
                    System.out.println("\nComparing " + query + " and " + doc);
                    System.out.println(testingVectorSpace.cosineSimilarity(query, doc));
                    similarity += testingVectorSpace.cosineSimilarity(query, doc);
                    comparisons++;
                }
            }

            // remove industryTwo company from corpus for next iteration
            documents.remove(query);
        }

        ArrayList<Document> documentsTwo = new ArrayList<Document>();

        // populate documents with industryTwo companies
        for (String company : industryTwoCompanies.keySet()) {
            Document d = new Document(company, industryTwoCompanies.get(company).keySet().iterator().next());
            documentsTwo.add(d);
        }

        double similarityTwo = 0;
        int comparisonsTwo = 0;

        // aggregate average cosine similarity data for 2 industries using industryTwo as foundational Corpus
        for (String company : industryOneCompanies.keySet()) {
            // add industryOne company to corpus for comparisons
            Document query = new Document(company, industryOneCompanies.get(company).keySet().iterator().next());
            documentsTwo.add(query);

            Corpus testingCorpus = new Corpus(documentsTwo);
            VectorSpaceModel testingVectorSpace = new VectorSpaceModel(testingCorpus);

            // compare industryTwo company to all industryOne companies
            for (Document doc : documentsTwo) {
                if (!doc.equals(query)) {
                    System.out.println("\nComparing " + query + " and " + doc);
                    System.out.println(testingVectorSpace.cosineSimilarity(query, doc));
                    similarityTwo += testingVectorSpace.cosineSimilarity(query, doc);
                    comparisonsTwo++;
                }
            }

            // remove industryTwo company from corpus for next iteration
            documentsTwo.remove(query);
        }

        System.out.println("Average similarity for inputted industries using industryOne as foundational Corpus: " +
                similarity/comparisons);
        System.out.println("Average similarity for inputted industries using industryTwo as foundational Corpus: " +
                similarityTwo/comparisonsTwo);
        System.out.println("Average similarity for inputted industries overall: " +
                (((similarity/comparisons) + (similarityTwo/comparisonsTwo))/2));
        System.out.println("Average rating difference for inputted industries: " +
                totalRatingDiff / comparisons);


    }
}