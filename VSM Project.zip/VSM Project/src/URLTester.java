
import java.net.URL;

/**
 * This class can try out URL connections
 */
public class URLTester {
    public static void main(String[] args) {
        URL redirected = null;

        URLGetter url = new URLGetter("https://www.upennrejects.com");
        url.printStatusCode();
        try{
            redirected = url.getRedirectURL();
            System.out.println("works");
        } catch (Exception e){
            e.printStackTrace();
        }
        System.out.println(redirected.toString());

    }
}
