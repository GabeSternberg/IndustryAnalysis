import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.IOException;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.HashSet;



public class MarketReader {
    String url;
    String cleanedURL;
    String countryURL;
    Integer questionNumber = 0;

    private Document currentDoc;
    public MarketReader(){
        url = "https://www.marketscreener.com/stock-exchange/sectors/";
        cleanedURL = "https://www.marketscreener.com";
        try{
            this.currentDoc = Jsoup.connect(url).get();
        } catch (IOException e) {
            System.out.println("Error Connecting To MS - Connection May Have Been Throttled, Try Using VPN");
            e.printStackTrace();
        }
    }

    // This method will return a map of an industry to another map of companies to their descriptions and ratings
    // @param firstIndustry the first industry to compare
    // @param secondIndustry the second industry to compare
    // @param sampleSize the number of companies to compare
    // @return a map of an industry to another map of companies to their descriptions and ratings
    public HashMap<String, HashMap<String, HashMap<ArrayList<String>, Float>>>
    runExperiment(String firstIndustry, String secondIndustry, String sampleSize) throws IOException {
        Integer counter = 0;
        String firstIndustryURL = getURL((firstIndustry), "img"); // Get the first industry URL
        String secondIndustryURL = getURL((secondIndustry), "img"); // Get the second industry URL
        Integer sampleSizeInt = Integer.parseInt(sampleSize); // Convert the sample size to an integer
        if(firstIndustryURL == null || secondIndustryURL == null){ // If either industry is not found, return null
            System.out.println("One of the industries was not found");
            return null;
        }
        System.out.println("First Industry URL: " + firstIndustryURL); // Print the first industry URL
        System.out.println("Second Industry URL: " + secondIndustryURL); // Print the second industry URL

        HashMap<String, HashMap<String, HashMap<ArrayList<String>, Float>>> industryToCompanies = new HashMap<>();

        HashMap<String, HashMap<ArrayList<String>, Float>> firstIndustryCompanies = getCompanies(firstIndustryURL, sampleSizeInt);

        HashMap<String, HashMap<ArrayList<String>, Float>> secondIndustryCompanies =
                getCompanies(secondIndustryURL, sampleSizeInt);
        industryToCompanies.put(firstIndustry, firstIndustryCompanies); // Add the first industry to the map
        industryToCompanies.put(secondIndustry, secondIndustryCompanies); // Add the second industry to the map
        return industryToCompanies; // Return the map

    }

    // @param searchFor the string to search for
    // @param tag the tag to search for
    // @return the URL

    public String getURL(String searchFor, String tag) throws IOException{ // Gets the URL from a given tag
        // if the tag contains the searchFor string
        Elements finder = currentDoc.select(tag); //Selects all the string from the html with tag
        Element desiredElement = null; //initialize the desiredElement to null
        for (Element elm : finder) { // For each element on the homepage, check if the text is the right one
            Element parent = elm.parent();
            if (elm.attr("alt").startsWith(searchFor)) {
                desiredElement = parent;
            }
        }

        if(desiredElement == null) {
            return "Not Found"; // If the inputted ocean doesn't exist, return "Ocean not found"
        }

        return cleanedURL + desiredElement.attr("href"); // Gather the url

    }

    // @param s the string to check
    // @return whether the string contains the word "quote"

    private static boolean containsQuote(String s) { // Check if a string contains the word "quote"
        // Regular expression to match URLs
        String urlRegex = "(http(s)?://)?([\\w-]+\\.)+[\\w-]+(/[\\w- ;,./?%&=]*)?";
        Pattern pattern = Pattern.compile(urlRegex);
        Matcher matcher = pattern.matcher(s);

        // Check if the string contains a URL and the phrase "quote"
        return matcher.find() && s.contains("quote");
    }

    // This method gets each company's description and rating for n companies (where n is the input, total)
    // @param industryURL the URL of the industry
    // @param total the number of companies to get
    // @return a map of companies to their descriptions and ratings
    public HashMap<String, HashMap<ArrayList<String>, Float>> getCompanies(String industryURL, Integer total)
            throws IOException{
        float companyRating = 0;
        ArrayList<String> wordList = new ArrayList<>();
        HashMap<ArrayList<String>, Float> companyRatings = new HashMap<>();
        HashMap<String, HashMap<ArrayList<String>, Float>> allCompanies = new HashMap<>();
        int count = 0;
        ArrayList<String> allCompanyURLs = getAllCompanyURLs(industryURL);
        allCompanyURLs.removeIf(s -> !containsQuote(s));

        for(String companyURL : allCompanyURLs){ // For each companyURL scraped, try to connect to it
            companyRatings = new HashMap<>();
            boolean descScraped = false;
            boolean ratingScraped = false;
            if(companyURL.equals("null") || companyURL == null){
                continue;
            }
            if(count >= total){
                System.out.println("All " + total + " Companies Reached!");
                break;
            }

            String[] parts = companyURL.split("/");
            String companyName = parts[parts.length - 1]; // Gather the company's name from the URL

            try{
                Document companyDoc = Jsoup.connect(companyURL).get();
            } catch (IOException e) {
                System.out.println("Error in connecting to " + companyURL);
                continue;
            }
            // Connect to the document
            Document companyDoc = Jsoup.connect(companyURL).get();
            Elements companyElements = companyDoc.select("div");

            for(Element elm : companyElements){ // For each element of a companies url, check if it contains the
                // description and rating. If so, add it to the map
                if(elm.attr("id").equals("companyProfile")) { // If the element contains the description,
                    // extract the description
                    Elements totalDivs = elm.select("div");
                    Element companyProfileURL = totalDivs.get(2);
                    Element nextDiv = companyProfileURL.selectFirst("div");
                    Element finalDiv = nextDiv.selectFirst("div");
                    try {
                        String cleanedText = finalDiv.text().replaceAll(
                                "[^a-zA-Z\\s]", "").toLowerCase();
                    } catch (NullPointerException e) {
                        System.out.println("Error in getting company description");
                        continue;
                    }
                    String cleanedText = finalDiv.text().replaceAll(
                            "[^a-zA-Z\\s]", "").toLowerCase();
                    int index = cleanedText.indexOf("   q");
                    String resultString;
                    if (index != -1) {
                        resultString = cleanedText.substring(0, index);
                    } else {
                        // If "   q" is not found, result is the same as original string
                        resultString = cleanedText;
                    }
                    String[] wordsArray = resultString.split("\\s+");
                    wordList = new ArrayList<>(Arrays.asList(wordsArray));
                    descScraped = true;
                }
                if(elm.attr("class").equals("consensus-gauge")){ // If the element contains the rating,
                    // extract the rating

                    String rating = elm.attr("title");
                    int startIndex = rating.indexOf(":") + 2; // Index of ":" plus 2 to skip the space after ":"
                    int endIndex = rating.indexOf("/", startIndex); // Index of "/" after the number
                    String ratingString = rating.substring(startIndex, endIndex).trim(); // Extract the number as a string
                    companyRating = Float.parseFloat(ratingString);
                    ratingScraped = true;

                }
                if(descScraped && ratingScraped){ // If both the description and rating are found, add the company to
                    // the map
                    System.out.println("Success! Description AND Rating Found For " + companyName);
                    System.out.println("Appending Company #" + (count+1) + " to the Map!");
                    companyRatings.put(wordList, companyRating);
                    allCompanies.put(companyName, new HashMap<>(companyRatings));
                    count++;
                    break;
                }
            }
        }
        if(count != total){ // If all companies are scraped and not enough companies are found, print the number of
            // companies found
            System.out.println("Only " + count + " Companies With Descriptions AND Ratings Were Listed.");
        }
        return allCompanies;
    }

    // This method gets all the company URLs from a given industry URL
    // @param industryURL the URL of the industry
    // @return a list of all the company URLs

    public ArrayList<String> getAllCompanyURLs (String industryURL) throws IOException{
        ArrayList<String> allCompanyURLs = new ArrayList<>();
        Document industryDoc = Jsoup.connect(industryURL).get();
        Elements companyElements = industryDoc.select("a");
        for(Element e : companyElements){ // For each element on the industries page, check if the href contains "quote"
            if(e.attr("href").contains("quote") == false ||
                    e.attr("href").contains("stock") == false){
                continue;
            }
            String companyURL = cleanedURL + e.attr("href"); //If it does, add it to the list of all
            // companyURLS
            allCompanyURLs.add(companyURL);

        }
        HashSet<String> uniqueStrings = new HashSet<>();
        ArrayList<String> resultList = new ArrayList<>();
        for (String str : allCompanyURLs) {
            if (uniqueStrings.add(str)) {
                // If the string is added to the HashSet (i.e., it's unique), add it to the result list
                resultList.add(str);
            }
        }
        resultList.subList(0, 7).clear();
        return resultList;
    }



}
